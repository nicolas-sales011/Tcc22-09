import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { validMpSignature, settlePayment } from '../pagamentos.js';

const secret = 'segredo-de-teste';
const sign = (dataId, requestId, ts, key = secret) =>
  `ts=${ts},v1=${createHmac('sha256', key).update(`id:${dataId};request-id:${requestId};ts:${ts};`).digest('hex')}`;

test('assinatura do webhook: aceita válida e recusa adulterada, sem segredo ou sem cabeçalho', () => {
  const headers = { 'x-signature': sign('123456', 'req-1', '1742505638683'), 'x-request-id': 'req-1' };
  assert.equal(validMpSignature({ secret, headers, dataId: '123456' }), true);
  assert.equal(validMpSignature({ secret, headers, dataId: '999999' }), false, 'id diferente');
  assert.equal(validMpSignature({ secret: 'outro', headers, dataId: '123456' }), false, 'segredo errado');
  assert.equal(validMpSignature({ secret: '', headers, dataId: '123456' }), false, 'sem segredo configurado');
  assert.equal(validMpSignature({ secret, headers: {}, dataId: '123456' }), false, 'sem cabeçalho');
  assert.equal(validMpSignature({ secret, headers: { ...headers, 'x-request-id': 'req-2' }, dataId: '123456' }), false);
});

function setup({ capacity = 3, booked = 0, price = 20, quantity = 1 } = {}) {
  const db = {
    users: [
      { id: 'p1', name: 'Marina', role: 'passageiro', active: true },
      { id: 'd1', name: 'Lucas', role: 'motorista', active: true },
      { id: 'a1', name: 'Admin', role: 'admin', active: true }
    ],
    trips: [{ id: 't1', driverId: 'd1', destination: 'Santos', capacity, price, status: 'agendada', approval: 'aprovada', deleted: false, date: new Date(Date.now() + 86400000).toISOString() }],
    reservations: booked ? [{ id: 'rx', tripId: 't1', userId: 'outro', quantity: booked, status: 'confirmada' }] : [],
    payments: [{ id: 'pay1', tripId: 't1', userId: 'p1', quantity, amount: price * quantity, method: 'pix', status: 'pendente', reservationId: null }],
    notifications: []
  };
  const calls = { refunds: [] };
  const deps = {
    db,
    notify: (d, userId, message) => d.notifications.push({ userId, message }),
    free: (d, t) => t.capacity - d.reservations.filter((r) => r.tripId === t.id && r.status === 'confirmada').reduce((s, r) => s + r.quantity, 0),
    newId: (() => { let n = 0; return () => 'id' + ++n; })(),
    refund: async (id) => { calls.refunds.push(String(id)); }
  };
  const mp = (extra = {}) => ({ id: 555, external_reference: 'pay1', status: 'approved', currency_id: 'BRL', transaction_amount: price * quantity, ...extra });
  return { db, deps, calls, mp };
}

test('pagamento aprovado cria a reserva e é idempotente (aviso repetido não duplica)', async () => {
  const { db, deps, mp } = setup({ quantity: 2 });
  assert.equal(await settlePayment({ ...deps, mp: mp() }), 'confirmado');
  assert.equal(db.reservations.length, 1);
  assert.equal(db.reservations[0].userId, 'p1');
  assert.equal(db.reservations[0].quantity, 2);
  assert.equal(db.payments[0].status, 'aprovado');
  assert.equal(await settlePayment({ ...deps, mp: mp() }), 'repetido');
  assert.equal(db.reservations.length, 1);
});

test('valor divergente não confirma a reserva e avisa o admin', async () => {
  const { db, deps, mp } = setup();
  assert.equal(await settlePayment({ ...deps, mp: mp({ transaction_amount: 1 }) }), 'divergente');
  assert.equal(db.reservations.length, 0);
  assert.ok(db.notifications.some((n) => n.userId === 'a1'));
});

test('viagem lotada enquanto pagava: reembolsa em vez de reservar', async () => {
  const { db, deps, calls, mp } = setup({ capacity: 1, booked: 1 });
  assert.equal(await settlePayment({ ...deps, mp: mp() }), 'reembolsado');
  assert.deepEqual(calls.refunds, ['555']);
  assert.equal(db.payments[0].status, 'reembolsado');
  assert.equal(db.reservations.length, 1, 'nenhuma reserva nova');
});

test('falha no reembolso deixa pendente e avisa o admin', async () => {
  const { db, deps, mp } = setup({ capacity: 1, booked: 1 });
  const out = await settlePayment({ ...deps, refund: async () => { throw new Error('indisponível'); }, mp: mp() });
  assert.equal(out, 'reembolso_pendente');
  assert.equal(db.payments[0].status, 'reembolso_pendente');
  assert.ok(db.notifications.some((n) => n.userId === 'a1'));
});

test('recusado e depois aprovado (nova tentativa) acaba confirmando', async () => {
  const { db, deps, mp } = setup();
  assert.equal(await settlePayment({ ...deps, mp: mp({ status: 'rejected' }) }), 'recusado');
  assert.equal(db.payments[0].status, 'recusado');
  assert.equal(await settlePayment({ ...deps, mp: mp() }), 'confirmado');
  assert.equal(db.reservations.length, 1);
});

test('estorno feito no painel cancela a reserva', async () => {
  const { db, deps, mp } = setup();
  await settlePayment({ ...deps, mp: mp() });
  assert.equal(await settlePayment({ ...deps, mp: mp({ status: 'refunded' }) }), 'estornado');
  assert.equal(db.reservations[0].status, 'cancelada');
  assert.equal(db.payments[0].status, 'reembolsado');
});

test('referência desconhecida é ignorada e pendente continua pendente', async () => {
  const { db, deps, mp } = setup();
  assert.equal(await settlePayment({ ...deps, mp: mp({ external_reference: 'nao-existe' }) }), 'ignorado');
  assert.equal(await settlePayment({ ...deps, mp: mp({ status: 'in_process' }) }), 'pendente');
  assert.equal(db.payments[0].status, 'pendente');
  assert.equal(db.reservations.length, 0);
});
