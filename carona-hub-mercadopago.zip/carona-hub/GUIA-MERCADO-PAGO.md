# Guia de integração: Mercado Pago no Carona Hub

## 1. A solução escolhida: Checkout Pro

O passageiro clica em **Pagar e reservar**, é levado à página segura do Mercado Pago, paga (cartão, Pix ou saldo) e volta ao site. O servidor só confirma a reserva depois que o Mercado Pago avisa, por um **webhook assinado**, que o pagamento foi aprovado.

Por que Checkout Pro e não as alternativas:

| Opção | Vantagem | Por que não agora |
|---|---|---|
| **Checkout Pro (adotado)** | Dados de cartão nunca passam pelo seu servidor, Pix e cartão prontos, pouco código | — |
| Checkout Transparente | Pagamento dentro do seu site | Mais código, mais responsabilidade com dados de cartão |
| Marketplace / split | Divide o valor entre plataforma e motorista automaticamente | Cada motorista precisa conectar a conta Mercado Pago (OAuth) e há regras de habilitação. É a evolução natural depois |

**Importante:** nesta versão o dinheiro cai na **sua** conta Mercado Pago (a da plataforma). O repasse aos motoristas fica por sua conta. Se quiser que o valor vá direto ao motorista com a sua comissão descontada, o próximo passo é o modelo marketplace.

## 2. O que mudou no projeto

| Arquivo | O que faz |
|---|---|
| `server.js` | Cria o pagamento, recebe o webhook, bloqueia reserva sem pagamento, reembolsa no cancelamento |
| `pagamentos.js` (novo) | Valida a assinatura do webhook e concilia o pagamento com a reserva |
| `store.js` e `database/schema.sql` | Nova tabela `tb_pagamento` (funciona em JSON e em MySQL) |
| `public/js/interacoes.js` | Redireciona ao Mercado Pago e trata a volta ao site |
| `tests/pagamentos.test.js` (novo) | 10 testes da assinatura e da conciliação |
| `.env.example` | Novas variáveis |

Sem `MERCADO_PAGO_ACCESS_TOKEN`, o site continua no **modo demonstração**, exatamente como antes.

## 3. Passo a passo

### 3.1 Instalar a dependência
Na pasta do projeto:

```
npm install
```

O `package.json` já lista `mercadopago`, mas ele não estava instalado em `node_modules`.

### 3.2 Criar a aplicação no Mercado Pago
1. Acesse **Mercado Pago Developers > Suas integrações** e crie uma aplicação.
2. Escolha o produto **Checkout Pro**.
3. Em **Credenciais de teste**, copie o **Access Token**.
4. Crie **contas de teste** (um vendedor e um comprador) na área de contas de teste. Use o comprador de teste para pagar no sandbox.

### 3.3 Expor o servidor com https (só para testar localmente)
O Mercado Pago precisa de um endereço público https para avisar o webhook. Use um túnel:

```
cloudflared tunnel --url http://localhost:3000
```
ou `ngrok http 3000`. Ele devolve um endereço como `https://algo.trycloudflare.com`.

### 3.4 Configurar o webhook
1. Em **Suas integrações > sua aplicação > Webhooks**, configure a URL:
   `https://SEU-ENDERECO/api/payment/webhook`
2. Marque o evento **Pagamentos**.
3. Revele e copie a **Assinatura secreta**.

### 3.5 Preencher o `.env`

```
APP_URL=https://SEU-ENDERECO
MERCADO_PAGO_ACCESS_TOKEN=<access token de teste>
MERCADO_PAGO_WEBHOOK_SECRET=<assinatura secreta>
```

Nunca coloque esses valores no front-end, no GitHub ou em conversa. O `.env` já está no `.gitignore`.

### 3.6 Rodar e testar

```
node start.js
```

1. Abra o endereço do túnel (não `localhost`), entre como passageiro e reserve uma carona.
2. Pague com o comprador de teste e os **cartões de teste** da documentação oficial (o nome do titular define se o pagamento é aprovado ou recusado; confira a tabela na doc).
3. Ao voltar ao site, aparece "Estamos confirmando sua reserva". Em poucos segundos o webhook chega e a reserva vira **confirmada**.
4. Teste também: pagamento recusado (nenhuma reserva é criada) e cancelamento de uma reserva paga (o reembolso é solicitado).

O terminal mostra avisos se faltar o segredo do webhook ou se o `APP_URL` não for https.

## 4. Como funciona e por que é seguro

1. `payment/session`: o servidor calcula o valor (preço x vagas), grava um pagamento **pendente** e cria a preferência no Mercado Pago com `external_reference`, expiração de 30 minutos e filtro da forma de pagamento escolhida.
2. O passageiro paga na página do Mercado Pago.
3. O Mercado Pago chama `POST /api/payment/webhook`. O servidor:
   - valida a assinatura (`x-signature`) com o seu segredo; sem assinatura válida responde 401;
   - **consulta o pagamento direto na API** (não confia no corpo do aviso);
   - confere valor e moeda; se divergir, não confirma e avisa o admin;
   - cria a reserva uma única vez (avisos repetidos não duplicam);
   - se a viagem lotou enquanto a pessoa pagava, **reembolsa automaticamente**.
4. A rota `reserve` fica **bloqueada** quando o Mercado Pago está ativo. Sem isso, qualquer pessoa conseguiria reservar sem pagar chamando a API direto.
5. Ao cancelar uma reserva paga, o reembolso é pedido **antes** de cancelar. Se o Mercado Pago falhar, nada muda e a pessoa pode tentar de novo.

## 5. Ir para produção
1. Ative as **credenciais de produção** da aplicação (o Mercado Pago pede dados do seu negócio) e troque o Access Token e a assinatura secreta no `.env`.
2. Hospede o site com **https** e domínio próprio, e ajuste `APP_URL` e a URL do webhook no painel.
3. Se o token de teste ou de produção chegou a ser compartilhado (por exemplo, dentro de um zip), gere um novo nas credenciais.
4. Faça um pagamento real de valor baixo e um reembolso para validar de ponta a ponta.

## 6. Decisões suas (o código assume o mais simples)
- **Política de reembolso:** hoje o cancelamento antes da saída devolve 100%. Se quiser taxa ou prazo, é um ajuste na rota `reservations/cancel`.
- **Repasse aos motoristas:** manual por enquanto (ver seção 1).
- **Pagamentos "reembolso_pendente":** se o reembolso automático falhar, o admin recebe uma notificação e devolve pelo painel do Mercado Pago.
- **Taxas do Mercado Pago:** são descontadas do valor recebido. Confira as tarifas vigentes no painel.
