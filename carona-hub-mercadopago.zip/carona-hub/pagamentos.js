import { createHmac, timingSafeEqual } from 'node:crypto';

/**
 * Valida o cabeçalho x-signature enviado pelo Mercado Pago.
 * Modelo assinado: id:<data.id>;request-id:<x-request-id>;ts:<ts>;
 * Chave: "Assinatura secreta" da aplicação (Suas integrações > Webhooks).
 * Sem segredo configurado, recusa tudo (falha fechada).
 */
export function validMpSignature({ secret, headers, dataId }) {
  if (!secret || !dataId) return false;

  const header = String(headers['x-signature'] || '');
  const requestId = String(headers['x-request-id'] || '');
  let ts = '';
  let v1 = '';

  for (const part of header.split(',')) {
    const [key, ...rest] = part.split('=');
    const value = rest.join('=').trim();

    if (key.trim() === 'ts') ts = value;
    else if (key.trim() === 'v1') v1 = value;
  }

  if (!ts || !v1) return false;

  // Conforme a documentação, ids alfanuméricos entram em minúsculas no modelo.
  const normalizedId = /^[a-z0-9]+$/i.test(dataId) ? dataId.toLowerCase() : dataId;
  const expected = createHmac('sha256', secret)
    .update(`id:${normalizedId};request-id:${requestId};ts:${ts};`)
    .digest('hex');

  const a = Buffer.from(expected);
  const b = Buffer.from(v1);

  return a.length === b.length && timingSafeEqual(a, b);
}

/**
 * Concilia um pagamento consultado direto na API do Mercado Pago com o registro local.
 * Regras importantes:
 *  - quem pagou, qual viagem e quantas vagas vêm do NOSSO registro, nunca do corpo do webhook;
 *  - é idempotente: o Mercado Pago pode enviar o mesmo aviso várias vezes;
 *  - se a viagem lotou ou mudou enquanto o usuário pagava, o valor é reembolsado.
 */
export async function settlePayment({ db, mp, refund, notify, free, newId }) {
  const record = db.payments.find((p) => p.id === mp.external_reference);

  if (!record) {
    return 'ignorado';
  }

  const now = new Date().toISOString();
  record.mpPaymentId = String(mp.id);
  record.updatedAt = now;

  const notifyAdmins = (message) =>
    db.users.filter((u) => u.role === 'admin' && u.active).forEach((u) => notify(db, u.id, message));

  if (mp.status === 'approved') {
    if (['aprovado', 'reembolsado', 'reembolso_pendente', 'divergente'].includes(record.status)) {
      return 'repetido';
    }

    if (mp.currency_id !== 'BRL' || Math.abs(Number(mp.transaction_amount) - record.amount) > 0.009) {
      record.status = 'divergente';
      notifyAdmins('Pagamento com valor divergente. Confira no painel do Mercado Pago: ' + mp.id);
      return 'divergente';
    }

    const trip = db.trips.find((t) => t.id === record.tripId);
    const canBook =
      trip &&
      !trip.deleted &&
      trip.approval === 'aprovada' &&
      trip.status === 'agendada' &&
      new Date(trip.date) > new Date() &&
      record.quantity <= free(db, trip) &&
      !db.reservations.some(
        (r) => r.tripId === trip.id && r.userId === record.userId && r.status === 'confirmada'
      );

    if (canBook) {
      const reservation = {
        id: newId(),
        tripId: trip.id,
        userId: record.userId,
        quantity: record.quantity,
        status: 'confirmada',
        date: now
      };

      db.reservations.push(reservation);
      record.reservationId = reservation.id;
      record.status = 'aprovado';

      const user = db.users.find((u) => u.id === record.userId);

      notify(db, record.userId, 'Pagamento aprovado! Reserva confirmada para ' + trip.destination + '.');
      notify(db, trip.driverId, (user?.name || 'Um passageiro') + ' reservou ' + record.quantity + ' vaga(s).');
      return 'confirmado';
    }

    record.status = 'reembolso_pendente';
    notify(
      db,
      record.userId,
      'Seu pagamento foi aprovado, mas a viagem não tem mais vagas disponíveis. Estamos devolvendo o valor.'
    );

    try {
      await refund(mp.id);
      record.status = 'reembolsado';
      return 'reembolsado';
    } catch (error) {
      console.error('[Mercado Pago] Falha ao reembolsar o pagamento', mp.id, error?.message || error);
      notifyAdmins('Reembolso pendente do pagamento ' + mp.id + '. Faça a devolução pelo painel do Mercado Pago.');
      return 'reembolso_pendente';
    }
  }

  if (mp.status === 'refunded' || mp.status === 'charged_back') {
    const reservation = record.reservationId
      ? db.reservations.find((r) => r.id === record.reservationId)
      : null;

    if (reservation && reservation.status === 'confirmada') {
      reservation.status = 'cancelada';
      notify(db, record.userId, 'Seu pagamento foi estornado e a reserva foi cancelada.');
    }

    record.status = 'reembolsado';
    return 'estornado';
  }

  if (record.status !== 'pendente') {
    return 'repetido';
  }

  if (mp.status === 'rejected') {
    record.status = 'recusado';
    return 'recusado';
  }

  if (mp.status === 'cancelled') {
    record.status = 'cancelado';
    return 'cancelado';
  }

  return 'pendente';
}
